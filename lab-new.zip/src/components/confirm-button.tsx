"use client";

export default function ConfirmButton({
                                          message,
                                          children,
                                          className = "btn",
                                      }: {
    message: string;
    children: React.ReactNode;
    className?: string;
}) {
    return (
        <button
            type="submit"
            className={className}
            onClick={(e) => {
                if (!window.confirm(message)) e.preventDefault();
            }}
        >
            {children}
        </button>
    );
}